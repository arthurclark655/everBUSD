<!doctype html>
<html lang="en">
<?php include('./components/header.php')?>
<body>
  <?php 
    include('./components/swaptokens/main.php');
    include('./components/footer.php');
  ?>
</body>
</html>