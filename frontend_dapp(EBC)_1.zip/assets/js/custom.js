
function copyContract(el) {
  $('div#contract').find('svg').each(function() {
    $(this).removeClass('copy_contract');
  });
  $(el).addClass('copy_contract');
  /* Get the text field */
  var copyText = $(el).parents('div.row').find('div.contractDiv').text();
   /* Copy the text inside the text field */
  navigator.clipboard.writeText(copyText);
}

