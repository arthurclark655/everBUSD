<div class="cd-content-wrapper">
  <div class="container">
    <!-- Earned, Wallet, Unclaimed -->
    <div class="row">
      <div class="col-md-3 col-xs-12">
        <div class="customDiv">
          <h4 class="text-center">Total Earned</h4>
          <div class="busdImg">
            <img src="assets/img/busd_32.png" />
          </div>
          <!-- Total Earned -->
          <p id="totalEarned" class="money">$0</p>
          <p class="coinType">BUSD</p>
        </div>
      </div>
      <div class="col-md-6 col-xs-12">
        <div class="customDiv">
          <h4 class="text-center">Your Wallet</h4>
          <div id='wallet'>
            <div class="walletDiv">
              <div class="busdImg">
                <img src="assets/img/logo.png" style="width: 55px; display: block; margin: 6px auto;"/>
              </div>
              <!-- Wallet EBC -->
              <p id="wallet_ebc" class="money">0</p>
              <p class="coinType">EBC</p>
            </div>
            <div class="walletDiv">
              <div class="busdImg">
                <img src="assets/img/busd_32.png" />
              </div>
              <!-- Wallet BUSD -->
              <p id="wallet_busd" class="money">$0</p>
              <p class="coinType">BUSD</p>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-xs-12">
        <div class="customDiv">
          <h4 class="text-center">Unclaimed Rewards</h4>
          <div class="busdImg">
            <img src="assets/img/busd_32.png" />
          </div>
          <!-- Unclaimed Rewards -->
          <p id="unclaimed" class="money">$0</p>
          <p class="coinType">BUSD</p>
        </div>
      </div>
    </div>

    <!-- Claim Manually -->
    <div id='claim' class="customDiv">
      <div id="description">
        <p class="text-center">Click Here to Claim Rewards Manually: </p>
      </div>
      <div id="claimbutton"> 
        <button class="btn w3-blue w3-hover-teal" disabled="true" onclick="claim(this)">CLAIM</button>
      </div>     
    </div>

    <!-- Total Rewards -->
    <div id='rewards' class="customDiv flex">
      <div id='totalRewards'>
        <div id='desc'>Total Rewards Distributed:</div>
        <div id="number">
          <img src="assets/img/busd_32.png" />
          <p id="total_Rewards">$0</p>
        </div>
      </div>
      <div id='contract'>
        <div class="row">
          <div class="col-md-3">EBC Contract</div>
          <div id='ebc_contract' class="col-md-8 contractDiv">0xe34D6230643Aa38cC6fB0FfdF77bf57250665025</div>
          <div class="col-md-1">        
            <span id='ebc_copy' class="iconify" data-icon="clarity:copy-line" onclick="copyContract(this)"></span>
          </div>
        </div>
        <div class="row">
          <div class="col-md-3">BUSD Contract</div>
          <div id='busd_contract' class="col-md-8 contractDiv">0xe9e7cea3dedca5984780bafc599bd69add087d56</div>
          <div class="col-md-1">
            <span id='busd_copy' class="iconify" data-icon="clarity:copy-line" onclick="copyContract(this)"></span>
          </div>
        </div>
      </div>      
    </div>

    <!-- Note -->
    <div id="note">
      Note: Rewards are designed to be sent automatically every 60 minutes. However it may take longer depending on your holdings and the trading volume.
      Rewards will be triggered once they are large enough to cover gas fees.
      If you are a smaller holder, it may take from a couple hours to a few days for rewards to appear in your wallet.
      You can also manually claim unclaimed rewards, but you will need to pay the gas fees.
    </div>
  </div>

  <!-- The Loading Modal -->
  <div class="modal" id="loader">
    <div class="modal-dialog modal-dialog-centered" style="background-color: transparent;">
      <div class="modal-content" style="background-color: transparent; border: none;">    
        <!-- Modal body -->
        <div class="modal-body text-center">
   			<div class="spinner-border text-primary"></div>
            <div>Loading . . .</div>
        </div>       
      </div>
    </div>
  </div>

</div>

<!-- .content-wrapper -->
</main> <!-- .cd-main-content -->