<header class="cd-main-header js-cd-main-header">
  <div class="cd-logo-wrapper">
    <a href="" style="margin: 0 10px;">
      <img src="assets/img/logo.png" alt="Logo" style="width: 40px;">
      <label id="logo">EverBUSD</label>
    </a>
  </div>
  
  <div class="cd-search js-cd-search" style="display: none;">
    <!-- <form>
      <input class="reset" type="search" placeholder="Search...">
    </form> -->
  </div>

  <button class="reset cd-nav-trigger js-cd-nav-trigger" aria-label="Toggle menu"><span></span></button>

  <ul class="cd-nav__list js-cd-nav__list">
    <li class="cd-nav__item w3-padding">
      <button id='connect' class="btn navbtn customBtn" onclick="onConnect()">CONNECT WALLET</button>
      <span id='wallet_address' class="navbtn" style="display: none; padding: 15px; background-color: transparent; color: white;">account info</span>
      <button id='dis_connect' class="btn navbtn customBtn" onclick="onDisconnect()" style="display: none;">DISCONNECT WALLET</button>
    </li>
  </ul>
</header> <!-- .cd-main-header -->

<main class="cd-main-content">
  <nav class="cd-side-nav js-cd-side-nav">
    <ul class="cd-side__list js-cd-side__list">
      <li class="cd-side__item cd-side__item--selected cd-side__item--overview">
        <a href=""><span class="iconify" data-icon="dashicons:money"></span>Earnings</a>
      </li>
      <li class="cd-side__item cd-side__item--overview">
        <!-- <a href="/blockchain-php/swaptokens" target='_blank'><span class="iconify" data-icon="mdi:swap-horizontal-circle"></span>Swap Tokens</a> -->
        <a href="/Dapp/swaptokens" target='_blank'><span class="iconify" data-icon="mdi:swap-horizontal-circle"></span>Swap Tokens</a>
      </li>
      <li class="cd-side__item cd-side__item--overview">
        <a href="https://everbusdcoin.com/" target="_blank"><span class="iconify" data-icon="whh:website"></span>Website</a>
      </li>
  
      <li class="cd-side__item cd-side__item--has-children cd-side__item--comments js-cd-item--has-children">
        <a href="#"><span class="iconify" data-icon="fluent:people-community-20-filled"></span>Communities</a>
        
        <ul class="cd-side__sub-list w3-animate-opacity">
          <li class="cd-side__sub-item"><a href="https://t.me/everbusdcoin" target="_blank"><span class="iconify" data-icon="la:telegram-plane"></span>Telegram</a></li>
          <li class="cd-side__sub-item"><a href="https://twitter.com/everbusdcoinEBC" target="_blank"><span class="iconify" data-icon="brandico:twitter-bird"></span>Twitter</a></li>
          <li class="cd-side__sub-item"><a href="#" target="_blank"><span class="iconify" data-icon="bi:facebook"></span>Facebook</a></li>
          <li class="cd-side__sub-item"><a href="#" target="_blank"><span class="iconify" data-icon="bi:reddit"></span>Reddit</a></li>
        </ul>
      </li>
    </ul>
  </nav>