<div class='cd-content-wrapper'>
  <div class='container'>
    <div id="swap_token">
      <img src="assets/img/swapToken.png" alt="swap etc" />
    </div>
  </div>
</div>