<nav class="navbar navbar-expand-md navbar-dark" id="swap_nav">
  <a class="navbar-brand" href="#">
    <img src="assets/img/logo.png" style="width: 40px;"/>
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Swap</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">dApp</a>
      </li>    
    </ul>
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <button id='connect' class="btn navbtn customBtn" onclick="onConnect()">Connect Wallet</button>
      </li> 
    </ul>
  </div>  
</nav>