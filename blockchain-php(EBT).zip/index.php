<!doctype html>
<html lang="en">
<?php include('./components/header.php')?>
<body>
  <?php 
    include('./components/nav.sidebar.php');
    include('./components/index/main.php');
    include('./components/footer.php');
    include('./components/index/script.php');
  ?>
</body>
</html>