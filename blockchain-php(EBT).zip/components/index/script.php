<script src="https://unpkg.com/web3@latest/dist/web3.min.js"></script>
<script type="text/javascript" src="https://unpkg.com/web3modal@1.9.0/dist/index.js"></script>
<script type="text/javascript" src="https://unpkg.com/evm-chains@0.2.0/dist/umd/index.min.js"></script>
<script type="text/javascript" src="https://unpkg.com/@walletconnect/web3-provider@1.2.1/dist/umd/index.min.js"></script>

<script>
const scanUrl = "https://bscscan.com/";
// Unpkg imports
const Web3Modal = window.Web3Modal.default;
const WalletConnectProvider = window.WalletConnectProvider.default;
const Fortmatic = window.Fortmatic;
const evmChains = window.evmChains;

// Web3modal instance
let web3Modal

// Chosen wallet provider given by the dialog window
let provider;

// Address of the selected account
let selectedAccount;

// abi, address
let abi = [];
let busdabi = [];
let address = '';
let busdaddress = '';

let contractForWrite, contractForBusd, contractForDistributor, contractForDistributorWrite;

const web3 = new Web3(new Web3.providers.HttpProvider("https://speedy-nodes-nyc.moralis.io/d01189c531451f39093c516f/bsc/mainnet"));


let connected = false;
let timer;
//-----------------------------------------------------------
$(document).ready(function() {
  (async function() {
    // Fetch abi datas
    abi = await getAbiData('config/abi.json');
    busdabi = await getAbiData('config/busdabi.json');
    distributorabi = await getAbiData('config/distributorabi.json');

    address = '0x7eD1CB3892684B02Ad7fca1F4784251C291f0e2B';
    busdaddress = '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56';
    dividenddistributoraddress = '0xe9f2eEc1dd927a01c6d41334676A6c19Ffbcf837';

    contractForWrite = new web3.eth.Contract(busdabi, address);
    contractForBusd = new web3.eth.Contract(busdabi, busdaddress);
    contractForDistributor = new web3.eth.Contract(distributorabi, dividenddistributoraddress);

    init();
  })();
});

/**
 * Setup the orchestra
 */
function init() {
  // console.log("WalletConnectProvider is", WalletConnectProvider);
  // console.log("window.web3 is", window.web3, "window.ethereum is", window.ethereum);

  // Tell Web3modal what providers we have available.
  // Built-in web browser provider (only one can exist as a time)
  // like MetaMask, Brave or Opera is added automatically by Web3modal
  const providerOptions = {
      walletconnect: {
          package: WalletConnectProvider,
          options: {
              // Mikko's test key - don't copy as your mileage may vary
              infuraId: "8043bb2cf99347b1bfadfb233c5325c0",
          }
      }
  };

  web3Modal = new Web3Modal({
      cacheProvider: true, // optional
      providerOptions, // required
      disableInjectedProvider: false, // optional. For MetaMask / Brave / Opera.
  });
  
  
  // console.log("Web3Modal instance is", web3Modal);

  fetch_totalDistributedValue();
  setInterval(async () => {
    await fetch_totalDistributedValue();
  }, 17000);

  onConnect();
}

async function fetch_totalDistributedValue() {
  const totalDistributedValue = await contractForDistributor.methods.totalDistributed().call();
  $("#total_Rewards").html('$' + approximateNumber(totalDistributedValue/10**18));
  // console.log("---totalDistributedValue---", totalDistributedValue/10**18);
}

// Connect Wallet
async function onConnect() {
  // console.log("Opening a dialog", web3Modal);
  try {
    $('button#connect').html('<span class="spinner-border text-primary" style="font-size: 10px;"></span>');
    provider = await web3Modal.connect();
    $('button#connect').html('CONNECT WALLET');
  } catch (e) {
    // console.log("Could not get a wallet connection", e);
    $('button#connect').html('CONNECT WALLET');
    return;
  }

  // Subscribe to accounts change
  provider.on("accountsChanged", (accounts) => {
      fetchAccountData();
  });

  // Subscribe to chainId change
  provider.on("chainChanged", (chainId) => {
      fetchAccountData();
  });

  // Subscribe to networkId change
  provider.on("networkChanged", (networkId) => {
      fetchAccountData();
  });

  connected = true;
  const loginWeb3 = new Web3(provider);
  contractForDistributorWrite = new loginWeb3.eth.Contract(distributorabi, dividenddistributoraddress);
  $('div#loader').modal('show');
  await refreshAccountData();  
  $('div#loader').modal('hide');

  // Run loading spinner at the first time.
  try {
    $('div#loader').modal('show');
    connected = true;
    await refreshAccountData();  
    $('div#loader').modal('hide');
  } catch(err) {
    // console.log(err);
    $('div#loader').modal('hide');
    connected = false;
    return;
  }  


  // Run Interval Timer.
  timer = setInterval(async () => {
    await refreshAccountData();
  }, 20000);  
}

// Disconnect Wallet
async function onDisconnect() {
  // console.log("Killing the wallet connection", provider);
  await web3Modal.clearCachedProvider();

  // TODO: Which providers have close method?
  if (provider.close) {
    await provider.close();

    // If the cached provider is not cleared,
    // WalletConnect will default to the existing session
    // and does not allow to re-scan the QR code with a new wallet.
    // Depending on your use case you may want or want not his behavir.
    // await web3Modal.clearCachedProvider();
    provider = null;
  }

  selectedAccount = null;
  connected = false;
  clearInterval(timer);
  
  $("#wallet_address").hide();
  $("#connect").show();
  $("#dis_connect").hide();

  $("#wallet_ebc").html('0');
  $("#unclaimed").html('$0');
  // $("#total_Rewards").html('$0');
  $("#totalEarned").html('$0');
  $("#wallet_busd").html('$0');

  $('div#claimbutton button').attr({disabled: true});
}


/**
 * Kick in the UI action after Web3modal dialog has chosen a provider
 */
async function fetchAccountData() {
  // Get a Web3 instance for the wallet
  
  // Get a Web3 instance for the wallet
  const web3 = new Web3(provider);
  // console.log("Web3 instance is", web3);

  // Get connected chain id from Ethereum node
  const chainId = await web3.eth.getChainId();
  // console.log("chainId", chainId)
  // Load chain information over an HTTP API
  const chainData = evmChains.getChain(chainId);

  // Get list of accounts of the connected wallet
  const accounts = await web3.eth.getAccounts();
  // $(".harvest button").prop("disabled", true);
  if (connected === false || accounts.length === 0) {
    // console.log('disconnect------------',accounts)
      onDisconnect();
      selectedAccount = null;
      return;
  }

  // MetaMask does not give you all accounts, only the selected account
  // console.log("Got accounts", accounts);
  selectedAccount = accounts[0];

  $("#wallet_address").html(selectedAccount.substr(0, 4).concat("...").concat(selectedAccount.substr(-4)));
  $("#wallet_address").show();
  $("#connect").hide();
  $("#dis_connect").show();

  const balance = await web3.eth.getBalance(selectedAccount);
  // console.log("balance", balance); 
  
  let price = await $.get({
      url: "https://api.binance.com/api/v3/ticker/price?symbol=BUSDUSDT"
  });
  price = parseFloat(price.price);
  $(".history .wallet_busd span").html((parseFloat(balance) * price).toPrecision(9));


  const ebcbalance = await contractForWrite.methods.balanceOf(selectedAccount).call();
  $("#wallet_ebc").html(approximateNumber(ebcbalance.slice(0, -9)));
  // console.log("ebcbalance", ebcbalance.slice(0, -9));

  const unclaimedRewards = await contractForDistributor.methods.getUnpaidEarnings(selectedAccount).call();
  $("#unclaimed").html('$' + approximateNumber(unclaimedRewards/10**18));
  // console.log("unclaimedRewards", unclaimedRewards/10**18);

  const totalRealisedValue = await contractForDistributor.methods.shares(selectedAccount).call();
  $("#totalEarned").html('$' + approximateNumber(totalRealisedValue["totalRealised"]/10**18));
  // console.log("totalRealisedValue", totalRealisedValue["totalRealised"]);

  const busdbalance = await contractForBusd.methods.balanceOf(selectedAccount).call();
  $("#wallet_busd").html('$' + approximateNumber(busdbalance/10**18));
  // console.log("busdbalance", approximateNumber(busdbalance/10**18));

  $('div#claimbutton button').attr({disabled: false});

  // let userInfo = await contractForRead.methods.getUserInfo(selectedAccount).call();
  // $(".user-total-deposit").html(web3.utils.fromWei(userInfo.totalDeposit, "ether").substr(0, 10));
  // $(".user-total-withdraw").html(web3.utils.fromWei(userInfo.totalWithdrawn, "ether").substr(0, 10));

  // const invitedUser = await contractForRead.methods.getUserTotalReferrals(selectedAccount).call();
  // $(".invited-users .amount").html(invitedUser);
  // const totalEarnings = await contractForRead.methods.getUserReferralTotalBonus(selectedAccount).call();
  // $(".total-earnings .amount").html(parseFloat(web3.utils.fromWei(totalEarnings, "ether")).toPrecision(9).substr(
  //     0, 10));
  
}

async function refreshAccountData() {
  // console.log('------refresh-------');
  await fetchAccountData(provider);
}

const contractForRead = new web3.eth.Contract(abi, address);
// console.log("contractForRead", contractForRead);

function setCookie(cname, cvalue, exdays) {
    const d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    let expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    let name = cname + "=";
    let ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

// Fetch Abi data
const getAbiData = async (dataUrl) => {
  const res = await fetch(dataUrl ,{
    headers : { 
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    }
  });
  return (await res.json());
};

async function claim(btn) {
  $(btn).prop("disabled", true);
  try {
    await contractForDistributorWrite.methods.claimDividend().send({
        from: selectedAccount
    });    
    fetchAccountData();
    // console.log("test");
  } catch (err) {
    // console.log(err);
  }
  $(btn).prop("disabled", false);
}

function approximateNumber(num) {
  if(!num) num = 0;
  return Math.round(num * 10**3) / 10**3;
}

</script>