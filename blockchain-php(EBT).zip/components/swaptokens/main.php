<div class='cd-content-wrapper'>
  <div class='container'>
    <h1 class='text-center w3-animate-opacity'>Coming Soon</h1>
  </div>
</div>